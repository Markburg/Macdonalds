// @author Mark van der Burg
window.addEventListener("load", (e) => {
    const HController = new HeaderController;
    HController.init();
});

class HeaderController {

    async init() {
        let Headerview = new HeaderSection();
        document.querySelector("header").append(Headerview.getView());
        console.log(Headerview);
    }
}