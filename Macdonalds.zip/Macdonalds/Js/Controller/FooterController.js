// @author Mark van der Burg
window.addEventListener("load", (e) => {
    const FController = new FooterController();
    FController.init();
});

class FooterController {

    async init() {
        let Footerview = new FooterSection();
        document.querySelector("main").append(Footerview.getView());
        console.log(Footerview);
    }
}