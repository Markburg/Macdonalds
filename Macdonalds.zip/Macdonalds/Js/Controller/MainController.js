// @author Mark van der Burg
window.addEventListener("load", (e) => {
    const MController = new MainController();
    MController.init();
});

class MainController {

    async init() {
        let MainView = new MainSection();
        document.querySelector("main").append(MainView.getView());
        console.log(MainView);
    }
}