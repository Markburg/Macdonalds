// @author Mark van der Burg

class FooterSection extends Component {

    constructor() {
        super("section");
        this.rootElement.id = "Footer";
        this.rootElement.classList.add("FooterSection");
        this.initView()
    }

    initView() {
        this.rootElement.innerHTML = `
        <p id="copyright">Mark van der Burg</p>
        `;
    }
}