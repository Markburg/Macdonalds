// @author Mark van der Burg

class HeaderSection extends Component {

    constructor() {
        super("section");
        this.rootElement.id = "Header";
        this.rootElement.classList.add("HeaderSection");
        this.initView()
    }

    initView() {
        this.rootElement.innerHTML = `
        <h1>Macdonald Burgers</h1>
        <div class="Burgers">Selecteer je burger</div>
        `;
    }
}