
window.addEventListener("load", function(){

    const choices = document.querySelectorAll("#B1, #B2, #B3, #B4, #B5");
    choices.forEach(element => element.addEventListener('click', event => {

        handleChoice(element.id);
    }))
}, false);


function handleChoice(id){
    const choices = document.querySelectorAll("#B1, #B2, #B3, #B4, #B5");
    choices.forEach(element => {
        if(id===element.id)
            element.setAttribute('style', 'background-color:green');
        else
            element.setAttribute('style', 'background-color:red');
    });

}