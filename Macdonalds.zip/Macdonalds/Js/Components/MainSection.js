// @author Mark van der Burg

class MainSection extends Component {

    constructor() {
        super("section");
        this.rootElement.id = "Main";
        this.rootElement.classList.add("MainSection");
        this.initView()
    }

    initView() {
        this.rootElement.innerHTML = `
        <div id="content">
                <img class="image" src="Pictures/Big%20mac.png">
                <div id="P1" class="Burger">Big Mac</div>
                <button id="B1" class="button ">select</button>

                <img class="image" src="Pictures/chickennugget.png">
                <div id="P2" class="Burger">Chickennugget</div>
                <button id="B2" class="button ">select</button>

                <img class="image" src="Pictures/Filetofish.png">
                <div id="P3" class="Burger">Filetofish</div>
                <button id="B3" class="button ">select</button>

                <img class="image" src="Pictures/macchicken.png">
                <div id="P4" class="Burger">Macchicken</div>
                <button id="B4" class="button ">select</button>

                <img class="image" src="Pictures/quarterpounder.png">
                <div id="P5" class="Burger">Quarterpounder</div>
                <button id="B5" class="button ">select</button>
            </div>
           
        `;
    }
}